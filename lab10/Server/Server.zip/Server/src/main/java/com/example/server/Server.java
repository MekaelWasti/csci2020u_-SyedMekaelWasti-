package com.example.server;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Server.class.getResource("hello-view.fxml"));

        //Set Up Server GUI Elements
        VBox vbox = new VBox();

        TextArea messageIncoming = new TextArea();
        Button exitButton = new Button("Exit");

        GridPane grid = new GridPane();
        grid.add(messageIncoming,0,0);
        grid.add(exitButton,0,1);

        grid.setVgap(10);
        grid.setPadding(new Insets(30,30,30,30));
        vbox.getChildren().add(grid);

        //Implement Functionality
        exitButton.setOnAction(actionEvent -> {
            Platform.exit();
            System.exit(0);
        });


        InetAddress ip = InetAddress.getByName("prism.ezyro.com");

        ServerSocket ss = new ServerSocket(4999);
        Socket s = ss.accept();
        System.out.println("Client Connected");


        Thread thread = new Thread(() -> {

            while (!ss.isClosed()) {
                BufferedReader br = null;
                try {
                    br = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    String str = br.readLine();
                    System.out.println(str);
                    messageIncoming.appendText(str + "\n");
                } catch (IOException e) {
                    try {
                        s.close();
                        br.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    e.printStackTrace();
                }
            }
        });

        thread.start();




        //Set Up Client GUI Window
        Scene scene = new Scene(vbox, 338.75, 217.25);
        stage.setTitle("Server");
        stage.setScene(scene);
        stage.show();


    }

    public static void main(String[] args) {
        launch();
    }
}